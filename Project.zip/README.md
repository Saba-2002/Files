https://www.turebi.ge/ka/

https://goodtravel.ge/

https://www.oktravel.ge/ka/

https://www.viator.com/Australia-tourism/d22-r20004411011-s216386291/4

https://www.gadventures.com/destinations/europe/italy/

https://www.travelstride.com/tour-operators/explore

https://www.keytours.gr/en/

https://www.getyourguide.com/

https://www.greca.co/en

https://www.viator.com/

https://stepsis.gr/   this is not for tourist site but has some great details

ზედა საიტების სხვადასხვა დეტალები გამოდგება რომ ავაგოთ ჩვენი საიტი. 

მთავარ გვერდზე ვთქვით რომ იყოს სლაიდი რამოდენიმე ფოტოსი რომელზეც მიბმული იქნება შესაბამისი ტურები. 

ასევე სლაიდის თავზე იყოს ძებნის ფუნქცია მიმართულების (destination) და თარიღის (თვე) მიხედვით. მაგ: https://www.greca.co/en და https://www.viator.com/
