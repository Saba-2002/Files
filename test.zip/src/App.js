import React from "react";
import './App.css';
import Footer from "./parts/Footer";


function App() {
  return (
    <div className="page-container">
      <div className="content-wrap">
        <h1>TEXT IS HERE!</h1>
      </div>
      <Footer />
    </div>

  );
}

export default App;
