import React from "react";
import "./Footer.css";
import logo from './download.png';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faYoutube,
  faFacebook,
  faTwitter,
  faInstagram
} from "@fortawesome/free-brands-svg-icons";



function Footer() {
    return (
      <div className="main-footer">
        <div className="container">
          <div className="row">
            {/* column1 */}
            <div className="col">
              <ul className="list">
                <li>Kutaisi International University is a public</li>
                <li>research university in Kutaisi , Georgia.</li>
                <li>Its construction was announced on 12</li>
                <li>September 2016.</li>         
              </ul>
            </div>
            {/* column2 */}
            <div className="col">
              <ul className="list">
                <li>
                  <a href="https://www.kiu.edu.ge/geo/about-us">About us</a>
                </li>
                <li>
                  <a href="https://www.kiu.edu.ge/index.php?m=230">Contact Us</a>
                </li>
                <li>
                  <a href="https://www.kiu.edu.ge/eng/research">Privacy Policy</a>
                </li>
              </ul>
            </div>
            {/* column3 */}
            <div className="col">
              <img src={logo} alt="Logo"/>
            </div>
            <div className="col">
              <a href="#" class="fa fa-facebook"></a>
            </div>
          </div>
          <hr />
          <div className="row">
            <p className="line">
              &copy; {new Date().getFullYear()} All rights reserved | Terms Of Service | Privacy
            </p>

          </div>
          <div className="social-links">
            <a href="https://www.youtube.com/c/KutaisiInternationalUniversity" 
              className="youtube social">
              <FontAwesomeIcon icon={faYoutube} size="2x" />
            </a>
            <a href="https://www.facebook.com/KutaisiInternationalUniversity/"
              className="facebook social">
              <FontAwesomeIcon icon={faFacebook} size="2x" />
            </a>
            <a href="https://www.instagram.com/univkiu/"
              className="instagram social">
              <FontAwesomeIcon icon={faInstagram} size="2x" />
            </a>
          </div>

        </div>
  
      </div>

    );
}

export default Footer;
